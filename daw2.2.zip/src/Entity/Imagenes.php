<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ImagenesRepository")
 */
class Imagenes
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $imagen;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\proyectos", inversedBy="imagenes")
     */
    private $id_proyecto;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getImagen(): ?string
    {
        return $this->imagen;
    }

    public function setImagen(string $imagen): self
    {
        $this->imagen = $imagen;

        return $this;
    }

    public function getIdProyecto(): ?proyectos
    {
        return $this->id_proyecto;
    }

    public function setIdProyecto(?proyectos $id_proyecto): self
    {
        $this->id_proyecto = $id_proyecto;

        return $this;
    }
}
