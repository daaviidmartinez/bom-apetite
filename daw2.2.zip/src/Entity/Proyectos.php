<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ProyectosRepository")
 */
class Proyectos
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $titulo;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $cliente;

    /**
     * @ORM\Column(type="date")
     */
    private $fechaInicio;

    /**
     * @ORM\Column(type="date")
     */
    private $fechaFin;

    /**
     * @ORM\Column(type="text")
     */
    private $descripcion;

    /**
     * @ORM\Column(type="decimal", precision=10, scale=2)
     */
    private $presupuesto;

    /**
     * @ORM\Column(type="smallint")
     */
    private $categoria;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Imagenes", mappedBy="id_proyecto")
     */
    private $imagenes;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\EquipoProyecto", mappedBy="id_proyecto")
     */
    private $equipoProyectos;

    public function __construct()
    {
        $this->imagenes = new ArrayCollection();
        $this->id_equipo = new ArrayCollection();
        $this->equipoProyectos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitulo(): ?string
    {
        return $this->titulo;
    }

    public function setTitulo(string $titulo): self
    {
        $this->titulo = $titulo;

        return $this;
    }

    public function getCliente(): ?string
    {
        return $this->cliente;
    }

    public function setCliente(string $cliente): self
    {
        $this->cliente = $cliente;

        return $this;
    }

    public function getFechaInicio(): ?\DateTimeInterface
    {
        return $this->fechaInicio;
    }

    public function setFechaInicio(\DateTimeInterface $fechaInicio): self
    {
        $this->fechaInicio = $fechaInicio;

        return $this;
    }

    public function getFechaFin(): ?\DateTimeInterface
    {
        return $this->fechaFin;
    }

    public function setFechaFin(\DateTimeInterface $fechaFin): self
    {
        $this->fechaFin = $fechaFin;

        return $this;
    }

    public function getDescripcion(): ?string
    {
        return $this->descripcion;
    }

    public function setDescripcion(string $descripcion): self
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    public function getPresupuesto(): ?string
    {
        return $this->presupuesto;
    }

    public function setPresupuesto(string $presupuesto): self
    {
        $this->presupuesto = $presupuesto;

        return $this;
    }

    public function getCategoria(): ?int
    {
        return $this->categoria;
    }

    public function setCategoria(int $categoria): self
    {
        $this->categoria = $categoria;

        return $this;
    }

    /**
     * @return Collection|Imagenes[]
     */
    public function getImagenes(): Collection
    {
        return $this->imagenes;
    }

    public function addImagene(Imagenes $imagene): self
    {
        if (!$this->imagenes->contains($imagene)) {
            $this->imagenes[] = $imagene;
            $imagene->setIdProyecto($this);
        }

        return $this;
    }

    public function removeImagene(Imagenes $imagene): self
    {
        if ($this->imagenes->contains($imagene)) {
            $this->imagenes->removeElement($imagene);
            // set the owning side to null (unless already changed)
            if ($imagene->getIdProyecto() === $this) {
                $imagene->setIdProyecto(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|EquipoProyecto[]
     */
    public function getEquipoProyectos(): Collection
    {
        return $this->equipoProyectos;
    }

    public function addEquipoProyecto(EquipoProyecto $equipoProyecto): self
    {
        if (!$this->equipoProyectos->contains($equipoProyecto)) {
            $this->equipoProyectos[] = $equipoProyecto;
            $equipoProyecto->setIdProyecto($this);
        }

        return $this;
    }

    public function removeEquipoProyecto(EquipoProyecto $equipoProyecto): self
    {
        if ($this->equipoProyectos->contains($equipoProyecto)) {
            $this->equipoProyectos->removeElement($equipoProyecto);
            // set the owning side to null (unless already changed)
            if ($equipoProyecto->getIdProyecto() === $this) {
                $equipoProyecto->setIdProyecto(null);
            }
        }

        return $this;
    }
}
