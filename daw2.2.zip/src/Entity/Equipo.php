<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EquipoRepository")
 */
class Equipo
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $miembro;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\EquipoProyecto", mappedBy="id_equipo")
     */
    private $equipoProyectos;

    public function __construct()
    {
        $this->equipoProyectos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMiembro(): ?string
    {
        return $this->miembro;
    }

    public function setMiembro(string $miembro): self
    {
        $this->miembro = $miembro;

        return $this;
    }

    /**
     * @return Collection|EquipoProyecto[]
     */
    public function getEquipoProyectos(): Collection
    {
        return $this->equipoProyectos;
    }

    public function addEquipoProyecto(EquipoProyecto $equipoProyecto): self
    {
        if (!$this->equipoProyectos->contains($equipoProyecto)) {
            $this->equipoProyectos[] = $equipoProyecto;
            $equipoProyecto->setIdEquipo($this);
        }

        return $this;
    }

    public function removeEquipoProyecto(EquipoProyecto $equipoProyecto): self
    {
        if ($this->equipoProyectos->contains($equipoProyecto)) {
            $this->equipoProyectos->removeElement($equipoProyecto);
            // set the owning side to null (unless already changed)
            if ($equipoProyecto->getIdEquipo() === $this) {
                $equipoProyecto->setIdEquipo(null);
            }
        }

        return $this;
    }
}
