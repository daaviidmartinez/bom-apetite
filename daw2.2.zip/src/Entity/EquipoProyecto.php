<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EquipoProyectoRepository")
 */
class EquipoProyecto
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\proyectos", inversedBy="equipoProyectos")
     */
    private $id_proyecto;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\equipo", inversedBy="equipoProyectos")
     */
    private $id_equipo;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIdProyecto(): ?proyectos
    {
        return $this->id_proyecto;
    }

    public function setIdProyecto(?proyectos $id_proyecto): self
    {
        $this->id_proyecto = $id_proyecto;

        return $this;
    }

    public function getIdEquipo(): ?equipo
    {
        return $this->id_equipo;
    }

    public function setIdEquipo(?equipo $id_equipo): self
    {
        $this->id_equipo = $id_equipo;

        return $this;
    }
}
