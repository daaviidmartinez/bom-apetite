<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200123093336 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE equipo (id INT AUTO_INCREMENT NOT NULL, miembro VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE equipo_proyecto (id INT AUTO_INCREMENT NOT NULL, id_proyecto_id INT DEFAULT NULL, id_equipo_id INT DEFAULT NULL, INDEX IDX_BAFF6DCBEE371C4D (id_proyecto_id), INDEX IDX_BAFF6DCB820E47CA (id_equipo_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE imagenes (id INT AUTO_INCREMENT NOT NULL, id_proyecto_id INT DEFAULT NULL, imagen VARCHAR(255) NOT NULL, INDEX IDX_376A6001EE371C4D (id_proyecto_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE proyectos (id INT AUTO_INCREMENT NOT NULL, titulo VARCHAR(50) NOT NULL, cliente VARCHAR(100) NOT NULL, fecha_inicio DATE NOT NULL, fecha_fin DATE NOT NULL, descripcion LONGTEXT NOT NULL, presupuesto NUMERIC(10, 2) NOT NULL, categoria SMALLINT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE equipo_proyecto ADD CONSTRAINT FK_BAFF6DCBEE371C4D FOREIGN KEY (id_proyecto_id) REFERENCES proyectos (id)');
        $this->addSql('ALTER TABLE equipo_proyecto ADD CONSTRAINT FK_BAFF6DCB820E47CA FOREIGN KEY (id_equipo_id) REFERENCES equipo (id)');
        $this->addSql('ALTER TABLE imagenes ADD CONSTRAINT FK_376A6001EE371C4D FOREIGN KEY (id_proyecto_id) REFERENCES proyectos (id)');
        $this->addSql('DROP TABLE plato');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE equipo_proyecto DROP FOREIGN KEY FK_BAFF6DCB820E47CA');
        $this->addSql('ALTER TABLE equipo_proyecto DROP FOREIGN KEY FK_BAFF6DCBEE371C4D');
        $this->addSql('ALTER TABLE imagenes DROP FOREIGN KEY FK_376A6001EE371C4D');
        $this->addSql('CREATE TABLE plato (id INT AUTO_INCREMENT NOT NULL, img VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, title VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, description VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, price VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('DROP TABLE equipo');
        $this->addSql('DROP TABLE equipo_proyecto');
        $this->addSql('DROP TABLE imagenes');
        $this->addSql('DROP TABLE proyectos');
    }
}
