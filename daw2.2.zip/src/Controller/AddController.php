<?php

namespace App\Controller;

use App\Entity\Proyectos;
use App\Entity\Imagenes;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class AddController extends AbstractController
{
    /**
     * @Route("/add", name="add")
     */
    public function index(EntityManagerInterface $entityManager)
    {
        foreach ($this->proyecto as $value) {
            $proyecto = new Proyectos();
            $proyecto->setTitulo($value['titulo']);
            $proyecto->setCliente($value['cliente']);
            $proyecto->setFechaInicio($value['fechaInicio']);
            $proyecto->setFechaFin($value['fechaFin']);
            $proyecto->setDescripcion($value['descripcion']);
            $proyecto->setPresupuesto($value['presupuesto']);
            $proyecto->setCategoria($value['categoria']);
            $entityManager = persist($proyecto);

            foreach ($value['imagenes'] as $img) {
                $imagen = new Imagenes();
                $imagen->setImagen($img);
                $imagen->setIdProyecto($proyecto);
                $entityManager = persist($imagen);
            }
        }

        $entityManager->flush();

        return $this->render('add/index.html.twig', [
            'controller_name' => 'AddController',
        ]);
    }

    private $proyecto = [
        [
            'id' => 1,
            'titulo' => "milk splashes",
            'imagenes' => ["milk.jpg", "eiffel.jpg"],
            'cliente' => "gabrielle hopkins",
            'fechaInicio' => "17/12/2016",
            'fechaFin' => "17/03/2017",
            'descripcion' => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur luctus neque eu aliquam ultricies. Mauris justo tortor, vehicula sit amet aliquam eget, vulputate non felis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent in nunc turpis. Suspendisse varius, ex non volutpat convallis, dolor sem egestas eros, sit amet varius ligula lacus in orci.\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut pretium in nulla non pellentesque. In mattis mi sit amet risus fermentum posuere. Nullam vitae leo dapibus, semper urna at, faucibus urna. Curabitur aliquam ante ligula, eu scelerisque eros commodo eget. Proin feugiat posuere erat, vitae posuere nibh.",
            'integrantes' => ["Elliot Alderson", "Angela Moss"],
            'presupuesto' => 152796,
            'categoria' => 5,
        ],
        [
            'id' => 2,
            'titulo' => "hexagon bokeh",
            'imagenes' => ["hexagon.jpg", "clouds-and-rainbow.jpg", "vector-flower-fullscreen.jpg"],
            'cliente' => "devin barrett",
            'fechaInicio' => "22/01/2017",
            'fechaFin' => "22/04/2017",
            'descripcion' => "Duis pharetra vulputate rutrum. Phasellus rhoncus purus sed scelerisque efficitur. Nulla erat ante, varius eu facilisis dictum, molestie vitae nunc. Integer eu augue sit amet sem imperdiet vehicula. Nunc sit amet eros euismod, sollicitudin libero semper, lacinia magna.\nAliquam accumsan condimentum libero, id lobortis velit. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Duis vitae ipsum mi.",
            'integrantes' => ["Elliot Alderson", "Angela Moss"],
            'presupuesto' => 266538,
            'categoria' => 1,
        ],
        [
            'id' => 3,
            'titulo' => "dandelion",
            'imagenes' => ["dandelion.jpg", "landscape.jpg"],
            'cliente' => "maura perkins",
            'fechaInicio' => "24/10/2017",
            'fechaFin' => "22/01/2018",
            'descripcion' => "Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed tortor mauris, tempus at dolor et, elementum pellentesque erat. Nullam lacinia quis arcu ac finibus.\nPraesent at dolor ultricies, consequat urna convallis, dapibus purus. Maecenas sodales neque vel justo imperdiet placerat. Duis in elit ligula. Integer odio est, dignissim ut lacus a, dignissim feugiat risus.",
            'integrantes' => ["Tyrell Wellick", "Darlene Alderson"],
            'presupuesto' => 2531298,
            'categoria' => 4,
        ],
        [
            'id' => 4,
            'titulo' => "eiffel tower",
            'imagenes' => ["eiffel.jpg", "clouds-and-rainbow.jpg", "dandelion.jpg"],
            'cliente' => "mikel welch",
            'fechaInicio' => "16/02/2018",
            'fechaFin' => "17/05/2018",
            'descripcion' => "Duis ullamcorper erat nec interdum mattis. Nam imperdiet magna ut dui lobortis dignissim. Cras placerat augue et mauris fringilla tincidunt. Aliquam laoreet euismod augue, nec vehicula odio aliquam eu. Nullam justo mi, facilisis a interdum sed, lacinia eget arcu. Vivamus pharetra bibendum nisi, quis accumsan nunc gravida at. Etiam tempus urna quis velit fringilla pulvinar.\nProin imperdiet ut magna in cursus. In facilisis ligula ante, eget egestas nibh pellentesque eu. Nam fringilla varius quam. Etiam sit amet fermentum dolor, nec tempor odio. Pellentesque est purus, feugiat vel facilisis vel, imperdiet sit amet magna. Nunc nec malesuada dolor. Suspendisse et augue mauris. Aliquam condimentum, tellus imperdiet gravida viverra, augue eros tincidunt arcu, eu pulvinar orci tellus vel nisi. Integer nec eros sed urna elementum malesuada mollis nec velit.",
            'integrantes' => ["Angela Moss", "Darlene Alderson"],
            'presupuesto' => 703518,
            'categoria' => 3,
        ],
        [
            'id' => 5,
            'titulo' => "clouds & rainbow",
            'imagenes' => ["clouds-and-rainbow.jpg", "sneakers.jpg"],
            'cliente' => "marcia kane",
            'fechaInicio' => "30/04/2018",
            'fechaFin' => "29/07/2018",
            'descripcion' => "Praesent convallis nisl elit, et dapibus nulla varius in. Ut tincidunt purus eu tellus interdum pharetra. Vivamus volutpat dolor sit amet urna condimentum elementum. Nam ullamcorper nisi in nunc commodo, id malesuada metus ornare. Donec a metus vitae sapien lacinia venenatis eu in ante. Sed nec urna in purus vehicula iaculis. Aenean efficitur venenatis odio ac gravida.\nAliquam odio sem, malesuada et arcu iaculis, lobortis tristique sem. Nam imperdiet luctus mauris id malesuada. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In ac porta orci. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae.",
            'integrantes' => ["Elliot Alderson", "Tyrell Wellick"],
            'presupuesto' => 909856,
            'categoria' => 1,
        ],
        [
            'id' => 6,
            'titulo' => "rural landscape",
            'imagenes' => ["landscape.jpg", "sneakers.jpg", "clouds-and-rainbow.jpg"],
            'cliente' => "ken navarro",
            'fechaInicio' => "29/01/2018",
            'fechaFin' => "29/04/2018",
            'descripcion' => "Maecenas neque tortor, semper eu ultrices in, sagittis non sapien. Phasellus sit amet erat et nulla pellentesque scelerisque. Duis cursus quis enim a mattis. Fusce varius non ante sit amet pharetra.\nUt ultricies mollis erat id fringilla. Maecenas ut dictum risus. Maecenas vel nibh ac lorem sagittis vestibulum ac eu tortor. Nullam accumsan tellus sed tincidunt posuere. Aenean ac libero vitae neque bibendum suscipit. Nunc efficitur scelerisque scelerisque. Donec efficitur gravida risus ac rutrum.",
            'integrantes' => ["Angela Moss", "Tyrell Wellick", "Darlene Alderson"],
            'presupuesto' => 487387,
            'categoria' => 4,
        ],
        [
            'id' => 7,
            'titulo' => "cosmic sneakers",
            'imagenes' => ["sneakers.jpg", "vector-flower-fullscreen.jpg"],
            'cliente' => "leslie haas",
            'fechaInicio' => "03/03/2017",
            'fechaFin' => "01/06/2017",
            'descripcion' => "Aenean malesuada, nisl eu tincidunt facilisis, nulla ante convallis enim, vitae iaculis elit felis at dui. Vestibulum porttitor tempor commodo. Aenean ut mauris vel mauris facilisis facilisis. Fusce id cursus turpis, eu eleifend urna. Cras elementum erat elementum, tempor mi eu, convallis nulla. Fusce pretium fringilla rutrum. In hac habitasse platea dictumst.\nNunc magna ligula, fermentum quis enim in, rhoncus pretium lacus. Donec augue quam, dictum eget sapien eget, venenatis vehicula nunc. Quisque posuere eleifend tempus. Suspendisse convallis est lobortis volutpat tincidunt. Nulla vitae interdum dui. Nam nec enim sit amet felis sagittis pretium vitae in dui. Nulla facilisi.",
            'integrantes' => ["Tyrell Wellick", "Darlene Alderson"],
            'presupuesto' => 853484,
            'categoria' => 4,
        ],
        [
            'id' => 8,
            'titulo' => "abstract vector",
            'imagenes' => ["vector-flower-fullscreen.jpg", "milk.jpg", "dandelion.jpg"],
            'cliente' => "jewel hooper",
            'fechaInicio' => "09/06/2017",
            'fechaFin' => "07/09/2017",
            'descripcion' => "Donec vel ultrices massa, id laoreet est. Nulla pharetra, est rutrum vehicula dignissim, ipsum nisi vulputate felis, nec egestas ante sem sit amet quam. Ut ut risus ultrices, iaculis erat at, fermentum ligula. Vivamus ultrices rhoncus nibh, eget ullamcorper erat fringilla quis. Integer sit amet sem ex. Praesent et tincidunt lorem. Nunc varius est in sollicitudin pellentesque.\nProin a leo in risus vulputate suscipit vitae a eros. Nullam bibendum augue diam, ut ultricies orci ullamcorper ut. Nulla luctus vel urna sit amet cursus. Ut id augue a orci tincidunt lacinia eu et neque. Fusce vel auctor libero. Cras felis dolor, aliquam a mollis et, facilisis nec purus. Vestibulum vestibulum feugiat varius. Vestibulum finibus velit justo, in volutpat sapien accumsan a.",
            'integrantes' => ["Elliot Alderson", "Darlene Alderson"],
            'presupuesto' => 323808,
            'categoria' => 3,
        ]
    ];
}
